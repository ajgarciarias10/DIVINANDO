#Set a text

def main(points, round):
    return "ROUND "+ str(round) + "  "+ str(points) +" Points" 